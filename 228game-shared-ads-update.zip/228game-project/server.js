import express from "express";
import dotenv from "dotenv";
import Parser from "rss-parser";
import gplay from "@mradex77/google-play-scraper";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import multer from "multer";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const parser = new Parser({ timeout: 12000 });
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

// Shared creator-game storage. Set UPLOAD_DIR to a persistent volume on the host.
const uploadDir = process.env.UPLOAD_DIR || path.join(__dirname, "data", "ads");
const adsIndexFile = path.join(uploadDir, "ads.json");
await fs.promises.mkdir(uploadDir, { recursive: true });
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, _file, cb) => cb(null, `${crypto.randomUUID()}.html`)
  }),
  limits: { fileSize: 15 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase();
    cb(null, [".html", ".htm"].includes(ext));
  }
});
async function readAds() {
  try { const data = JSON.parse(await fs.promises.readFile(adsIndexFile, "utf8")); return Array.isArray(data) ? data : []; }
  catch { return []; }
}
async function writeAds(items) {
  const temp = `${adsIndexFile}.tmp`;
  await fs.promises.writeFile(temp, JSON.stringify(items, null, 2), "utf8");
  await fs.promises.rename(temp, adsIndexFile);
}
function creatorAuthorized(req) {
  const expected = String(process.env.CREATOR_CODE || "nois");
  const supplied = String(req.get("x-creator-code") || req.body?.code || "");
  const a = Buffer.from(expected), b = Buffer.from(supplied);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
app.post("/api/creator/verify", (req, res) => {
  if (!creatorAuthorized(req)) return res.status(401).json({ error: "کد ورود درست نیست." });
  res.json({ ok: true });
});
app.get("/api/ads", async (_req, res) => {
  const items = await readAds();
  res.json({ items: items.sort((a, b) => b.created - a.created).map(({ id, title, description, fileName, created }) => ({ id, title, description, fileName, created })) });
});
app.post("/api/ads", (req, res, next) => {
  if (!creatorAuthorized(req)) return res.status(401).json({ error: "اجازه ثبت بازی وجود ندارد؛ دوباره وارد پنل سازندگان شو." });
  upload.single("game")(req, res, async err => {
    if (err) return res.status(400).json({ error: err.code === "LIMIT_FILE_SIZE" ? "حداکثر حجم فایل ۱۵ مگابایت است." : "فقط فایل HTML یا HTM پذیرفته می‌شود." });
    try {
      if (!req.file) return res.status(400).json({ error: "فایل HTML بازی انتخاب نشده است." });
      const title = String(req.body?.title || "").trim().slice(0, 80);
      const description = String(req.body?.description || "").trim().slice(0, 1200);
      if (title.length < 2 || description.length < 5) {
        await fs.promises.unlink(req.file.path).catch(() => {});
        return res.status(400).json({ error: "عنوان و توضیحات را کامل وارد کن." });
      }
      const items = await readAds();
      const item = { id: path.basename(req.file.filename, ".html"), title, description, fileName: path.basename(req.file.originalname), storedFile: req.file.filename, created: Date.now() };
      items.push(item); await writeAds(items);
      res.status(201).json({ ok: true, item: { id: item.id, title, description, fileName: item.fileName, created: item.created } });
    } catch (e) { next(e); }
  });
});
app.get("/api/ads/:id/play", async (req, res) => {
  const item = (await readAds()).find(a => a.id === req.params.id);
  if (!item) return res.status(404).send("این بازی پیدا نشد.");
  res.set({
    "Content-Type": "text/html; charset=utf-8",
    "Content-Disposition": "inline",
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": "sandbox allow-scripts allow-forms; default-src https: data: blob:; script-src https: 'unsafe-inline' 'unsafe-eval'; style-src https: 'unsafe-inline'; img-src https: data: blob:; connect-src https:;"
  });
  res.sendFile(path.join(uploadDir, item.storedFile));
});

const newsFeeds = [
  { name: "IGN", url: "https://feeds.feedburner.com/ign/news" },
  { name: "GameSpot", url: "https://www.gamespot.com/feeds/news/" },
  { name: "PC Gamer", url: "https://www.pcgamer.com/feeds.xml" },
  { name: "Eurogamer", url: "https://www.eurogamer.net/feed" }
];
let newsCache = { at: 0, items: [] };
const categoryNewsCache = new Map();
const newsGameQueries = {
  "fortnite": "Fortnite game",
  "minecraft": "Minecraft game",
  "call-of-duty": "Call of Duty game",
  "roblox": "Roblox game",
  "free-fire": "Garena Free Fire game",
  "pubg": "PUBG game"
};
let allGamesCache = { at: 0, items: [] };
let wikidataGamesCache = { at: 0, items: [] };
const wikidataById = new Map();
const TEN_MINUTES = 10 * 60 * 1000;
const starterGames = [
  {id:"starter-minecraft",name:"Minecraft",released:"2011-11-18",rating:4.5,background_image:"",genres:["Sandbox","Adventure"],platforms:["PC","PlayStation","Xbox","Nintendo Switch","Mobile"],esrb:"Everyone 10+",description:"یک بازی جهان‌باز برای ساخت‌وساز، کاوش و ماجراجویی در دنیایی بلوکی.",developers:["Mojang Studios"],website:"https://www.minecraft.net/"},
  {id:"starter-roblox",name:"Roblox",released:"2006-09-01",rating:4.2,background_image:"",genres:["Sandbox","Social"],platforms:["PC","Mobile","Xbox","PlayStation"],esrb:"Everyone 10+",description:"پلتفرمی برای تجربه و ساخت بازی‌های متنوع توسط کاربران.",developers:["Roblox Corporation"],website:"https://www.roblox.com/"},
  {id:"starter-rocket-league",name:"Rocket League",released:"2015-07-07",rating:4.1,background_image:"",genres:["Sports","Racing"],platforms:["PC","PlayStation","Xbox","Nintendo Switch"],esrb:"Everyone",description:"فوتبال ماشینی سریع و رقابتی.",developers:["Psyonix"],website:"https://www.rocketleague.com/"},
  {id:"starter-fall-guys",name:"Fall Guys",released:"2020-08-04",rating:3.8,background_image:"",genres:["Platformer","Party"],platforms:["PC","PlayStation","Xbox","Nintendo Switch"],esrb:"Everyone",description:"مسابقه‌های گروهی رنگارنگ با مرحله‌های مانع‌دار.",developers:["Mediatonic"],website:"https://www.fallguys.com/"},
  {id:"starter-stardew",name:"Stardew Valley",released:"2016-02-26",rating:4.4,background_image:"",genres:["Simulation","RPG"],platforms:["PC","Mobile","PlayStation","Xbox","Nintendo Switch"],esrb:"Everyone 10+",description:"زندگی در مزرعه، کشاورزی، ماهیگیری و دوستی با ساکنان شهر.",developers:["ConcernedApe"],website:"https://www.stardewvalley.net/"},
  {id:"starter-terraria",name:"Terraria",released:"2011-05-16",rating:4.2,background_image:"",genres:["Sandbox","Adventure"],platforms:["PC","Mobile","PlayStation","Xbox","Nintendo Switch"],esrb:"Everyone 10+",description:"ماجراجویی دوبعدی با ساخت‌وساز، اکتشاف و مبارزه فانتزی.",developers:["Re-Logic"],website:"https://terraria.org/"},
  {id:"starter-among-us",name:"Among Us",released:"2018-06-15",rating:3.6,background_image:"",genres:["Party","Strategy"],platforms:["PC","Mobile","PlayStation","Xbox","Nintendo Switch"],esrb:"Everyone 10+",description:"بازی گروهی استنتاج و همکاری برای پیدا کردن خرابکار.",developers:["Innersloth"],website:"https://www.innersloth.com/games/among-us/"},
  {id:"starter-sims4",name:"The Sims 4",released:"2014-09-02",rating:3.8,background_image:"",genres:["Simulation"],platforms:["PC","PlayStation","Xbox"],esrb:"Teen",description:"شبیه‌ساز زندگی برای ساخت شخصیت‌ها و مدیریت داستان زندگی آن‌ها.",developers:["Maxis"],website:"https://www.ea.com/games/the-sims/the-sims-4"},
  {id:"starter-overcooked2",name:"Overcooked! 2",released:"2018-08-07",rating:4.0,background_image:"",genres:["Co-op","Simulation"],platforms:["PC","PlayStation","Xbox","Nintendo Switch"],esrb:"Everyone",description:"آشپزی دونفره و گروهی در آشپزخانه‌های پرچالش.",developers:["Ghost Town Games"],website:"https://www.team17.com/games/overcooked-2/"},
  {id:"starter-portal2",name:"Portal 2",released:"2011-04-19",rating:4.5,background_image:"",genres:["Puzzle","Adventure"],platforms:["PC","PlayStation","Xbox"],esrb:"Everyone 10+",description:"حل معماهای خلاقانه با استفاده از تفنگ پورتال.",developers:["Valve"],website:"https://www.thinkwithportals.com/"},
  {id:"starter-trackmania",name:"Trackmania",released:"2020-07-01",rating:3.9,background_image:"",genres:["Racing"],platforms:["PC"],esrb:"Everyone",description:"مسابقه اتومبیل‌رانی با مسیرهای مهارتی و زمان‌گیری.",developers:["Ubisoft Nadeo"],website:"https://www.trackmania.com/"},
  {id:"starter-lego-fortnite",name:"LEGO Fortnite",released:"2023-12-07",rating:4.0,background_image:"",genres:["Survival","Sandbox"],platforms:["PC","PlayStation","Xbox","Nintendo Switch"],esrb:"Teen",description:"ماجراجویی و ساخت‌وساز در دنیای لگویی فورتنایت.",developers:["Epic Games"],website:"https://www.fortnite.com/"}
];
const starterSteamCoverIds = {
  "Fall Guys": 1097150, "Stardew Valley": 413150, "Terraria": 105600, "Among Us": 945360,
  "The Sims 4": 1222670, "Overcooked! 2": 728880, "Portal 2": 620, "Trackmania": 2225070,
  "Human: Fall Flat": 477160, "Slime Rancher": 433340, "Ori and the Blind Forest": 261570,
  "Plants vs. Zombies": 3590, "Sonic Mania": 584400, "Forza Horizon 5": 1551360,
  "Sea of Thieves": 1172620, "Brawlhalla": 291550, "Chess Ultra": 518060,
  "LEGO Star Wars: The Skywalker Saga": 920210, "Disney Dreamlight Valley": 1401590
};
starterGames.forEach(game => {
  const appId = starterSteamCoverIds[game.name];
  if (appId && !game.background_image) game.background_image = `https://cdn.akamai.steamstatic.com/steam/apps/${appId}/header.jpg`;
});
const starterById = new Map(starterGames.map(g => [g.id, g]));

function cleanText(value = "", maxLength = 3000) {
  return String(value)
    .replace(/<\/(p|div|li|h[1-6]|br)>/gi, "\n")
    .replace(/<br\s*\/?\s*>/gi, "\n")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, " ").replace(/\n\s*\n\s*\n/g, "\n\n")
    .trim().slice(0, maxLength);
}
function isTeenSuitable(game) {
  // The public catalogue intentionally limits browsing to ESRB Everyone / Everyone 10+ / Teen.
  // Unknown ratings are omitted rather than assumed suitable.
  const rating = game.esrb_rating?.slug;
  return ["everyone", "everyone-10-plus", "teen"].includes(rating);
}

const persianGameAliases = {
  "ماینکرفت": "Minecraft", "ماین کرافت": "Minecraft", "ماین‌کرافت": "Minecraft",
  "روبلاکس": "Roblox", "روبلوکس": "Roblox",
  "کلش آف کلنز": "Clash of Clans", "کلش اف کلنز": "Clash of Clans", "کلش رویال": "Clash Royale",
  "پابجی": "PUBG MOBILE", "پابجی موبایل": "PUBG MOBILE",
  "فری فایر": "Free Fire", "فری فایر مکس": "Free Fire MAX",
  "کندی کراش": "Candy Crush Saga", "سابوی": "Subway Surfers", "ساب وی سورفرز": "Subway Surfers",
  "تمپل ران": "Temple Run 2", "آمیزینگ": "Among Us", "امانگ آس": "Among Us",
  "براول استارز": "Brawl Stars", "براول استار": "Brawl Stars",
  "کالاف": "Call of Duty Mobile", "کالاف دیوتی": "Call of Duty Mobile",
  "جنشین": "Genshin Impact", "گنشین ایمپکت": "Genshin Impact",
  "استامبل گایز": "Stumble Guys", "استامبل": "Stumble Guys",
  "فورتنایت": "Fortnite", "سیمز": "The Sims Mobile", "فیفا": "EA SPORTS FC Mobile",
  "استاردو ولی": "Stardew Valley", "استاردو": "Stardew Valley", "تریاریا": "Terraria", "فال گایز": "Fall Guys",
  "راکت لیگ": "Rocket League", "ماریو": "Super Mario", "سوپر ماریو": "Super Mario", "زلدا": "The Legend of Zelda",
  "سونیک": "Sonic", "اوری": "Ori and the Blind Forest", "انیمال کراسینگ": "Animal Crossing",
  "هومن فال فلت": "Human: Fall Flat", "پورتال دو": "Portal 2", "پورتال ۲": "Portal 2"
};
function normalizeSearchText(value = "") {
  return String(value).toLocaleLowerCase("fa")
    .replace(/[يى]/g, "ی").replace(/ك/g, "ک")
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/\s+/g, " ").trim();
}
function queryVariants(value = "") {
  const q = normalizeSearchText(value).slice(0, 100);
  const mapped = Object.entries(persianGameAliases).find(([key]) => normalizeSearchText(key) === q)?.[1];
  return [...new Set([String(value).trim(), mapped].filter(Boolean))];
}
function safePlayGame(game) {
  const rating = String(game.contentRating || game.contentRatingDescription || "").toLowerCase();
  if (/mature\s*17|adults?\s*only|pegi\s*18|18\+|adult/.test(rating)) return false;
  const text = `${game.title || ""} ${game.genre || ""} ${game.description || game.summary || ""}`.toLowerCase();
  if (/casino|sports betting|real.money gambling|slot machine|poker room/.test(text)) return false;
  if (/first.person shooter|battle royale|shooting game|gunfight|weapon|firearm|sniper|military shooter|war shooter/.test(text)) return false;
  return true;
}
function mapPlayGame(g) {
  return {
    id: `gp:${g.appId || g.id}`,
    appId: g.appId || g.id,
    name: g.title || g.name || "بازی بدون نام",
    released: g.released || g.updated || "",
    rating: g.score || g.rating || null,
    background_image: g.icon || g.headerImage || "",
    genres: [g.genre || g.genreId].filter(Boolean),
    platforms: ["Android"],
    esrb: g.contentRating || "رده‌بندی اعلام‌نشده",
    developers: [g.developer].filter(Boolean),
    description: cleanText(g.summary || g.description || "اطلاعات بیشتر در صفحه فروشگاه Google Play موجود است."),
    website: g.url || `https://play.google.com/store/apps/details?id=${encodeURIComponent(g.appId || g.id)}`,
    storeUrl: g.url || `https://play.google.com/store/apps/details?id=${encodeURIComponent(g.appId || g.id)}`,
    source: "Google Play"
  };
}
async function searchPlayStore(term, limit = 40) {
  const variants = queryVariants(term);
  const results = [];
  for (const variant of variants) {
    for (const lang of (/[\u0600-\u06ff]/.test(variant) ? ["fa", "en"] : ["en", "fa"])) {
      try {
        const found = await gplay.search({ term: variant, num: limit, lang, country: "us", category: gplay.category.GAME });
        for (const item of found || []) if (safePlayGame(item)) results.push(mapPlayGame(item));
      } catch (error) {
        console.warn("Google Play search failed:", error.message);
      }
      if (results.length >= limit) break;
    }
    if (results.length >= limit) break;
  }
  const seen = new Set();
  return results.filter(g => { if (seen.has(g.appId)) return false; seen.add(g.appId); return true; }).slice(0, limit);
}

// RAWG provides a cross-platform catalogue (PC, console and mobile). Keep the key server-side.
const RAWG_BASE = "https://api.rawg.io/api";
const rawgCache = new Map();
async function rawgRequest(endpoint, params = {}) {
  if (!process.env.RAWG_API_KEY) throw new Error("RAWG_API_KEY is not configured");
  const url = new URL(`${RAWG_BASE}${endpoint}`);
  url.searchParams.set("key", process.env.RAWG_API_KEY);
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, String(v));
  const cacheKey = url.toString().replace(process.env.RAWG_API_KEY, "KEY");
  const cached = rawgCache.get(cacheKey);
  if (cached && Date.now() - cached.at < 15 * 60 * 1000) return cached.data;
  const response = await fetch(url, { signal: AbortSignal.timeout(15000), headers: { "Accept": "application/json" } });
  if (!response.ok) throw new Error(`RAWG API responded ${response.status}`);
  const data = await response.json();
  rawgCache.set(cacheKey, { at: Date.now(), data });
  return data;
}
function safeRawgGame(game) {
  const rating = game.esrb_rating?.slug || "";
  if (["mature", "adults-only", "pegi-18"].includes(rating)) return false;
  const tags = (game.tags || []).map(t => `${t.name || ""} ${t.slug || ""}`).join(" ").toLowerCase();
  const genres = (game.genres || []).map(g => `${g.name || ""} ${g.slug || ""}`).join(" ").toLowerCase();
  const text = `${game.name || ""} ${tags} ${genres}`.toLowerCase();
  // Keep the public teen catalogue focused on non-weapon, non-gambling games.
  if (/\b(shooter|first.person.shooter|fps|gun|guns|weapon|military|warfare|battle.royale|sniper|casino|gambling|poker|slot.machine)\b/.test(text)) return false;
  return true;
}
function mapRawgGame(g) {
  return {
    id: `rawg:${g.id}`, rawgId: g.id, name: g.name || "بازی بدون نام", released: g.released || "",
    rating: g.rating || null, metacritic: g.metacritic || null, background_image: g.background_image || "",
    genres: (g.genres || []).map(x => x.name).filter(Boolean),
    platforms: (g.platforms || []).map(x => x.platform?.name).filter(Boolean),
    esrb: g.esrb_rating?.name || "رده‌بندی اعلام‌نشده", developers: [],
    description: cleanText(g.description_raw || g.description || "توضیحات کامل این بازی با بازکردن صفحه جزئیات دریافت می‌شود."),
    website: g.website || "", storeUrl: g.website || `https://rawg.io/games/${encodeURIComponent(g.slug || "")}`,
    source: "RAWG", rawgUrl: `https://rawg.io/games/${encodeURIComponent(g.slug || "")}`
  };
}
async function rawgList({ q = "", page = 1, pageSize = 20, popular = false } = {}) {
  const variants = q ? queryVariants(q) : [""];
  const collected = [];
  for (const term of variants.slice(0, 2)) {
    const data = await rawgRequest("/games", {
      page, page_size: Math.min(40, pageSize * 2), search: term || undefined,
      ordering: popular ? "-rating" : "-added", exclude_additions: "true", exclude_parents: "true"
    });
    for (const item of data.results || []) if (safeRawgGame(item)) collected.push(item);
    if (collected.length >= pageSize) break;
  }
  const unique = [...new Map(collected.map(g => [g.id, g])).values()].slice(0, pageSize);
  return { count: 1000, page, pageSize, results: unique.map(mapRawgGame), source: "RAWG global game database", catalogueLimit: 1000 };
}

let popularPlayCache = { at: 0, items: [] };
async function getPopularPlayGames() {
  if (popularPlayCache.items.length && Date.now() - popularPlayCache.at < 30 * 60 * 1000) return popularPlayCache.items;
  try {
    const list = await gplay.list({ collection: gplay.collection.TOP_FREE, category: gplay.category.GAME, num: 30, lang: "en", country: "us" });
    const items = (list || []).filter(safePlayGame).slice(0, 10).map(mapPlayGame);
    if (items.length) { popularPlayCache = { at: Date.now(), items }; return items; }
  } catch (error) { console.warn("Google Play popular list failed:", error.message); }
  return starterGames.slice(0, 10).map(g => ({ ...g, id: String(g.id), appId: String(g.id), source: "228GAME starter list" }));
}

// Search Aparat on the server and return a real video page URL (/v/<id>),
// instead of sending the visitor to an unreliable search route.
let aparatClientPromise;
async function getAparatClient() {
  if (!aparatClientPromise) {
    aparatClientPromise = import("aparat.js").then(mod => {
      const Aparat = mod.Aparat || mod.default?.Aparat;
      if (!Aparat) throw new Error("Aparat client export was not found");
      return new Aparat();
    });
  }
  return aparatClientPromise;
}
app.get("/api/aparat/gameplay", async (req, res) => {
  const name = String(req.query.name || "").trim().slice(0, 100);
  if (!name) return res.status(400).json({ error: "نام بازی ارسال نشده است." });
  try {
    const aparat = await getAparatClient();
    const videos = await aparat.video.search(`${name} گیم پلی`);
    const valid = (Array.isArray(videos) ? videos : []).filter(v =>
      typeof v?.url === "string" && /^https?:\/\/(www\.)?aparat\.com\/v\/[a-zA-Z0-9]+\/?$/.test(v.url)
    );
    if (!valid.length) return res.status(404).json({ error: "ویدئوی مستقیمی برای این بازی پیدا نشد." });
    const best = valid.find(v => /گیم\s*پلی|gameplay|walkthrough|let.?s play/i.test(`${v.title || ""} ${v.description || ""}`)) || valid[0];
    res.set("Cache-Control", "public, max-age=300");
    return res.json({ url: best.url, title: best.title || name, source: "Aparat" });
  } catch (error) {
    console.warn("Aparat gameplay search failed:", error.message);
    return res.status(502).json({ error: "جست‌وجوی آپارات موقتاً در دسترس نیست. سرور باید به اینترنت وصل باشد." });
  }
});

app.get("/api/status", (_req, res) => {
  res.json({
    gamesApiReady: Boolean(process.env.RAWG_API_KEY),
    gamesSource: process.env.RAWG_API_KEY ? "RAWG global game database" : "starter catalogue; RAWG key required for 1000-game catalogue",
    rawgReady: Boolean(process.env.RAWG_API_KEY),
    aiReady: Boolean(process.env.AI_API_KEY && process.env.AI_MODEL),
    aiLocalReady: true,
    newsRefreshMinutes: 10,
    cataloguePageSize: 20,
    allGamesPage: Boolean(process.env.RAWG_API_KEY),
    translationReady: true,
    catalogueTarget: "Up to 1000 cross-platform games through RAWG pagination"
  });
});

app.get("/api/translate", async (req, res) => {
  const text = String(req.query.text || "").trim().slice(0, 160);
  if (!text) return res.status(400).json({ error: "متن برای ترجمه ارسال نشده است." });
  try {
    const url = new URL("https://translate.googleapis.com/translate_a/single");
    url.searchParams.set("client", "gtx"); url.searchParams.set("sl", "auto");
    url.searchParams.set("tl", "en"); url.searchParams.set("dt", "t"); url.searchParams.set("q", text);
    const response = await fetch(url, { signal: AbortSignal.timeout(10000), headers: { "User-Agent": "Mozilla/5.0 228GAME" } });
    if (!response.ok) throw new Error(`Translation service responded ${response.status}`);
    const data = await response.json();
    const translated = (data?.[0] || []).map(part => part?.[0] || "").join("").trim();
    if (!translated) throw new Error("No translated text returned");
    return res.json({ original: text, translated, sourceLanguage: data?.[2] || "auto", targetLanguage: "en" });
  } catch (error) {
    return res.status(502).json({ error: "ترجمه آنلاین فعلاً در دسترس نیست؛ جست‌وجوی نام اصلی انجام بده." });
  }
});

app.get("/api/games/popular", async (_req, res) => {
  if (process.env.RAWG_API_KEY) {
    try {
      const data = await rawgList({ page: 1, pageSize: 10, popular: true });
      return res.json({ ...data, results: data.results.slice(0, 10), pageSize: 10, source: "۱۰ بازی پیشنهادی از RAWG" });
    } catch (error) { console.warn("RAWG popular list failed:", error.message); }
  }
  const results = await getPopularPlayGames();
  res.json({ count: results.length, page: 1, pageSize: 10, results, source: "فهرست پشتیبان 228GAME", cached: true });
});

app.get("/api/games", async (req, res) => {
  const q = String(req.query.q || "").trim();
  const page = Math.max(1, Math.min(50, Number.parseInt(req.query.page || "1", 10) || 1));
  const pageSize = 20;
  if (process.env.RAWG_API_KEY) {
    try {
      const data = await rawgList({ q, page, pageSize, popular: !q });
      return res.json({ ...data, count: Math.min(1000, data.count || 1000), catalogueLimit: 1000 });
    } catch (error) { console.warn("RAWG catalogue error:", error.message); }
  }
  try {
    if (q) {
      const results = await searchPlayStore(q, 30);
      return res.json({ count: results.length, page, pageSize: 30, results, source: "Google Play fallback", query: q, fallback: true });
    }
    const popular = await getPopularPlayGames();
    return res.json({ count: popular.length, page: 1, pageSize: 10, results: popular, source: "فهرست پشتیبان؛ برای ۱۰۰۰ بازی کلید RAWG لازم است", fallback: true });
  } catch (error) {
    console.warn("Catalogue fallback error:", error.message);
    const variants = queryVariants(q).map(normalizeSearchText);
    const backup = starterGames.filter(g => !q || variants.some(v => normalizeSearchText(g.name).includes(v) || v.includes(normalizeSearchText(g.name))));
    return res.json({ count: backup.length, page: 1, pageSize, results: backup.map(g => ({ ...g, id: String(g.id), appId: String(g.id) })), source: "228GAME offline catalogue", fallback: true });
  }
});

async function getWikidataCatalogue(limit = 1000) {
  if (wikidataGamesCache.items.length >= limit && Date.now() - wikidataGamesCache.at < 24 * 60 * 60 * 1000) {
    return wikidataGamesCache.items.slice(0, limit);
  }
  // CC0 Wikidata facts; restrict this public discovery list to broadly suitable genres.
  const sparql = `SELECT ?game ?gameLabel ?releaseDate ?genreLabel ?platformLabel WHERE {
    ?game wdt:P31/wdt:P279* wd:Q7889; wdt:P400 ?platform; wdt:P136 ?genre.
    ?game rdfs:label ?gameLabel. FILTER(LANG(?gameLabel) = "en")
    ?genre rdfs:label ?genreLabel. FILTER(LANG(?genreLabel) = "en")
    ?platform rdfs:label ?platformLabel. FILTER(LANG(?platformLabel) = "en")
    OPTIONAL { ?game wdt:P577 ?releaseDate. }
    FILTER(LCASE(STR(?genreLabel)) IN (
      "puzzle video game", "platform game", "racing video game", "simulation video game",
      "sports video game", "adventure game", "strategy video game", "casual game",
      "music video game", "educational game", "board game", "party game", "rhythm game",
      "sandbox game", "construction and management simulation", "life simulation game",
      "visual novel", "interactive fiction"
    ))
    FILTER(!REGEX(LCASE(STR(?gameLabel)), "war|shooter|sniper|gun|casino|gambling|horror|combat"))
  } LIMIT 5000`;
  const url = new URL("https://query.wikidata.org/sparql");
  url.searchParams.set("query", sparql);
  url.searchParams.set("format", "json");
  const response = await fetch(url, { signal: AbortSignal.timeout(45000), headers: { "Accept": "application/sparql-results+json", "User-Agent": "228GAME/1.0 (game catalogue; contact: site-admin)" } });
  if (!response.ok) throw new Error(`Wikidata responded ${response.status}`);
  const payload = await response.json();
  const unique = new Map();
  for (const row of payload.results?.bindings || []) {
    const uri = row.game?.value || "";
    const qid = uri.split("/").pop();
    const name = cleanText(row.gameLabel?.value || "", 140);
    if (!/^Q\d+$/.test(qid) || !name || unique.has(qid)) continue;
    const platform = cleanText(row.platformLabel?.value || "", 80);
    const genre = cleanText(row.genreLabel?.value || "", 80);
    const release = row.releaseDate?.value || "";
    const item = {
      id: `wd:${qid}`, name, released: release ? release.slice(0, 10) : "",
      rating: null, background_image: "", genres: genre ? [genre] : [],
      platforms: platform ? [platform] : [], esrb: "رده‌بندی نیازمند بررسی",
      developers: [], website: `https://www.wikidata.org/wiki/${qid}`,
      storeUrl: `https://www.wikidata.org/wiki/${qid}`,
      rawgUrl: `https://www.wikidata.org/wiki/${qid}`,
      description: `${name} در پایگاه داده آزاد Wikidata ثبت شده است. اطلاعات تکمیلی و صفحه رسمی بازی را از پیوند منبع بررسی کن.`,
      source: "Wikidata (CC0)"
    };
    unique.set(qid, item);
  }
  const results = [...unique.values()].slice(0, limit);
  wikidataGamesCache = { at: Date.now(), items: results };
  for (const game of results) wikidataById.set(game.id, game);
  return results;
}

app.get("/api/games/all", async (_req, res) => {
  if (allGamesCache.items.length && Date.now() - allGamesCache.at < 20 * 60 * 1000) {
    return res.json({ results: allGamesCache.items, count: allGamesCache.items.length, cached: true, limit: 1000 });
  }
  if (!process.env.RAWG_API_KEY) {
    try {
      const results = await getWikidataCatalogue(1000);
      if (results.length) return res.json({ results, count: results.length, limit: 1000, limited: results.length < 1000, source: "Wikidata CC0", message: results.length < 1000 ? `فعلاً ${results.length} عنوان مناسب از Wikidata دریافت شد.` : "۱۰۰۰ عنوان از Wikidata دریافت شد." });
    } catch (error) { console.warn("Wikidata catalogue failed:", error.message); }
    const results = starterGames.map(game => ({ ...game, id: String(game.id) }));
    return res.json({ results, count: results.length, limit: 1000, limited: true, message: "دریافت فهرست آزاد Wikidata ناموفق بود؛ برای کاتالوگ کامل، RAWG_API_KEY را در تنظیمات سرور وارد کن." });
  }
  try {
    const collected = new Map();
    // RAWG returns up to 40 titles per page. Fetch 25 pages in small batches.
    for (let start = 1; start <= 25 && collected.size < 1000; start += 5) {
      const batch = await Promise.all(Array.from({ length: Math.min(5, 26 - start) }, (_, i) =>
        rawgRequest("/games", { page: start + i, page_size: 40, ordering: "-added", exclude_additions: "true", exclude_parents: "true" })
          .catch(error => { console.warn("RAWG all-games page failed:", error.message); return { results: [] }; })
      ));
      for (const data of batch) {
        for (const game of data.results || []) {
          if (safeRawgGame(game) && !collected.has(game.id)) collected.set(game.id, game);
          if (collected.size >= 1000) break;
        }
        if (collected.size >= 1000) break;
      }
    }
    const results = [...collected.values()].slice(0, 1000).map(mapRawgGame);
    allGamesCache = { at: Date.now(), items: results };
    return res.json({ results, count: results.length, limit: 1000, cached: false, limited: results.length < 1000,
      message: results.length < 1000 ? "بانک RAWG پس از حذف عناوین نامناسب کمتر از ۱۰۰۰ بازی مناسب برگرداند." : "۱۰۰۰ بازی دریافت شد." });
  } catch (error) {
    console.warn("RAWG all-games list failed:", error.message);
    return res.status(502).json({ error: "دریافت کاتالوگ ۱۰۰۰ بازی از RAWG ناموفق بود." });
  }
});

app.get("/api/games/:id", async (req, res) => {
  const rawId = String(req.params.id);
  if (rawId.startsWith("wd:")) {
    const known = wikidataById.get(rawId);
    if (known) return res.json(known);
    return res.status(404).json({ error: "اطلاعات تکمیلی این بازی در حافظه سرور موجود نیست؛ صفحه منبع را بررسی کن." });
  }
  if (rawId.startsWith("rawg:") && process.env.RAWG_API_KEY) {
    try {
      const id = rawId.slice(5);
      const detail = await rawgRequest(`/games/${encodeURIComponent(id)}`);
      if (!safeRawgGame(detail)) return res.status(404).json({ error: "این عنوان در فهرست عمومی 228GAME نمایش داده نمی‌شود." });
      const mapped = mapRawgGame(detail);
      return res.json({ ...mapped, description: cleanText(detail.description_raw || detail.description || mapped.description, 5000), developers: (detail.developers || []).map(x => x.name), publishers: (detail.publishers || []).map(x => x.name), platforms: (detail.platforms || []).map(x => x.platform?.name).filter(Boolean), website: detail.website || mapped.website, rawgUrl: mapped.rawgUrl });
    } catch (error) { return res.status(502).json({ error: "جزئیات بازی از RAWG دریافت نشد.", detail: error.message }); }
  }
  const appId = rawId.startsWith("gp:") ? rawId.slice(3) : rawId;
  if (starterById.has(rawId)) return res.json(starterById.get(rawId));
  try {
    const detail = await gplay.app({ appId, lang: "en", country: "us" });
    if (!safePlayGame(detail)) return res.status(404).json({ error: "این عنوان در فهرست عمومی 228GAME نمایش داده نمی‌شود." });
    res.json({ ...mapPlayGame(detail), description: cleanText(detail.description || detail.summary), screenshots: detail.screenshots || [], video: detail.video || "", installs: detail.installs || "", updated: detail.updated || "", contentRating: detail.contentRating || "" });
  } catch (error) { res.status(502).json({ error: "جزئیات بازی از فروشگاه دریافت نشد.", detail: error.message }); }
});

const mediaCache = new Map();
app.get("/api/games/:id/media", async (req, res) => {
  const id = String(req.params.id);
  if (id.startsWith("rawg:") && process.env.RAWG_API_KEY) {
    const rawgId = id.slice(5);
    const cacheKey = `rawg:${rawgId}`;
    if (mediaCache.has(cacheKey)) return res.json(mediaCache.get(cacheKey));
    try {
      const [shots, movies] = await Promise.all([
        rawgRequest(`/games/${encodeURIComponent(rawgId)}/screenshots`, { page_size: 20 }),
        rawgRequest(`/games/${encodeURIComponent(rawgId)}/movies`).catch(() => ({ results: [] }))
      ]);
      const videos = (movies.results || []).map(movie => {
        const data = movie.data || {};
        const direct = [data.max, data["720"], data["480"], data["360"]].find(v => typeof v === "string" && /^https:\/\//i.test(v)) || "";
        const yt = movie.youtube_id || movie.youtubeId || "";
        const watchUrl = yt ? `https://www.youtube.com/watch?v=${yt}` : direct;
        return { title: movie.name || "ویدئوی معرفی بازی", url: watchUrl, youtubeId: yt, directUrl: direct, thumbnail: movie.preview || "", source: "RAWG" };
      }).filter(v => v.url).slice(0, 8);
      const result = { images: (shots.results || []).map(x => x.image).filter(Boolean).slice(0, 16), videos, source: "RAWG", rawgUrl: `https://rawg.io/games/${rawgId}` };
      mediaCache.set(cacheKey, result);
      return res.json(result);
    } catch (error) {
      console.warn("RAWG media lookup failed:", error.message);
      return res.json({ images: [], videos: [], source: "RAWG", notice: "رسانه این بازی فعلاً در دسترس نبود." });
    }
  }
  const appId = id.startsWith("gp:") ? id.slice(3) : id;
  const cacheKey = `gp:${appId}`;
  if (mediaCache.has(cacheKey)) return res.json(mediaCache.get(cacheKey));
  try {
    const detail = await gplay.app({ appId, lang: "en", country: "us" });
    const screenshots = (detail.screenshots || []).filter(Boolean).slice(0, 16);
    const videoUrl = detail.video || "";
    const videoId = videoUrl.match(/(?:v=|youtu\.be\/|embed\/)([A-Za-z0-9_-]{6,})/)?.[1] || "";
    const result = { images: screenshots.length ? screenshots : [detail.icon].filter(Boolean), videos: videoUrl ? [{ title: `${detail.title || "Game"} معرفی و گیم‌پلی`, url: videoUrl, youtubeId: videoId, directUrl: /\.mp4(?:$|\?)/i.test(videoUrl) ? videoUrl : "", thumbnail: detail.icon || "", source: "Google Play listing" }] : [], source: "Google Play" };
    mediaCache.set(cacheKey, result);
    return res.json(result);
  } catch (error) { return res.json({ images: [], videos: [], source: "none", notice: "رسانه این بازی در دسترس نبود." }); }
});

app.get("/api/news", async (req, res) => {
  const game = String(req.query.game || "").trim().toLowerCase();
  if (game) {
    const query = newsGameQueries[game];
    if (!query) return res.status(400).json({ error: "دسته خبری ناشناخته است." });
    const cached = categoryNewsCache.get(game);
    if (cached && Date.now() - cached.at < TEN_MINUTES) return res.json({ items: cached.items, cached: true, updatedAt: cached.at, game });
    try {
      const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(`${query} when:1d`)}&hl=en-US&gl=US&ceid=US:en`;
      const parsed = await parser.parseURL(rssUrl);
      const now = Date.now();
      const items = (parsed.items || []).map(item => ({
        source: item.creator || item.author || "Google News",
        title: cleanText(item.title, 500),
        summary: cleanText(item.contentSnippet || item.content || item.summary || "خبر از منبع اصلی؛ برای جزئیات بیشتر وارد لینک شوید.", 500),
        link: item.link,
        date: item.isoDate || item.pubDate || ""
      })).filter(item => {
        if (!item.title || !item.link) return false;
        const time = new Date(item.date).getTime();
        return !Number.isFinite(time) || now - time <= 24 * 60 * 60 * 1000;
      }).sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0)).slice(0, 30);
      categoryNewsCache.set(game, { at: Date.now(), items });
      return res.json({ items, cached: false, updatedAt: Date.now(), game, window: "last-24-hours", source: "Google News RSS" });
    } catch (error) {
      console.warn(`News feed failed for ${game}:`, error.message);
      if (cached) return res.json({ items: cached.items, cached: true, stale: true, updatedAt: cached.at, game });
      return res.status(502).json({ error: "خبرخوان این دسته موقتاً در دسترس نیست." });
    }
  }
  if (Date.now() - newsCache.at < TEN_MINUTES && newsCache.items.length) {
    return res.json({ items: newsCache.items, cached: true, updatedAt: newsCache.at });
  }
  const batches = await Promise.allSettled(newsFeeds.map(async feed => {
    const parsed = await parser.parseURL(feed.url);
    return (parsed.items || []).slice(0, 15).map(item => ({
      source: feed.name, title: cleanText(item.title),
      summary: cleanText(item.contentSnippet || item.content || item.summary),
      link: item.link, date: item.isoDate || item.pubDate || ""
    })).filter(item => item.title && item.link);
  }));
  const items = batches.flatMap(x => x.status === "fulfilled" ? x.value : [])
    .sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0)).slice(0, 60);
  if (items.length) newsCache = { at: Date.now(), items };
  res.json({ items: items.length ? items : newsCache.items, cached: items.length === 0, updatedAt: newsCache.at, refreshMinutes: 10, sources: newsFeeds.map(f => ({name:f.name, url:f.url})) });
});

function localGameAnswer(message) {
  const q = message.toLowerCase();
  const game = starterGames.find(g => q.includes(g.name.toLowerCase()));
  if (game) {
    return `درباره ${game.name}: ${game.description}\n\nسبک‌ها: ${game.genres.join('، ')}\nپلتفرم‌ها: ${game.platforms.join('، ')}\nسازنده: ${game.developers.join('، ')}\nتاریخ انتشار ثبت‌شده: ${game.released || 'نامشخص'}\n\nاگر درباره داستان، مراحل، شخصیت‌ها یا راهنمای بازی سؤال دقیق‌تری داری، اسم بخش موردنظرت را هم بنویس. برای پاسخ‌های گسترده درباره بازی‌های خارج از فهرست، باید کلید سرویس هوش مصنوعی در سرور تنظیم شود.`;
  }
  if (/سلام|درود|hello|hi/.test(q)) return 'سلام! من 228 AI هستم. درباره بازی‌ها، سبک‌ها، پلتفرم‌ها، سازنده‌ها و راهنمای بازی‌ها از من بپرس.';
  if (/بهترین بازی|بازی خوب|پیشنهاد بازی/.test(q)) return 'برای پیشنهاد بهتر، سبک موردعلاقه‌ات را بگو؛ مثلاً جهان‌باز، مسابقه‌ای، معمایی، ساخت‌وساز یا همکاری چندنفره. چند نمونه در فهرست محلی 228GAME: Minecraft، Rocket League، Terraria و Stardew Valley.';
  if (/تریلر|ویدئو/.test(q)) return 'برای تماشای تریلر، یک بازی را از بانک بازی‌ها باز کن و یکی از ویدئوهای قابل‌جاسازی را انتخاب کن. بعضی ناشرها پخش داخل سایت را می‌بندند؛ در آن حالت دکمه بازکردن در YouTube را بزن.';
  if (/آپدیت|به.?روزرسانی|نسخه جدید/.test(q)) return 'برای اطلاع از آخرین آپدیت‌ها باید خبرهای رسمی همان بازی بررسی شوند. در بخش اخبار 228GAME تیترها را ببین؛ من بدون اتصال منبع زنده، تاریخ یا جزئیات تازه را حدس نمی‌زنم.';
  return 'می‌توانم در حالت محلی درباره بازی‌های موجود در فهرست 228GAME و موضوعات عمومی گیمینگ کمک کنم، اما برای پاسخ دقیق درباره هر بازی در دنیا، اتصال یک سرویس هوش مصنوعی با کلید API لازم است. در تنظیمات سرور، AI_API_KEY و AI_MODEL را وارد کنید؛ کلید را داخل HTML قرار ندهید.';
}

app.post("/api/ai", async (req, res) => {
  const message = String(req.body?.message || "").trim().slice(0, 2000);
  if (!message) return res.status(400).json({ error: "پیام خالی است." });
  if (!process.env.AI_API_KEY || !process.env.AI_MODEL) {
    return res.json({ answer: localGameAnswer(message), mode: "local-knowledge" });
  }
  const base = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const history = Array.isArray(req.body?.messages) ? req.body.messages.slice(-10).map(m => ({
    role: m?.role === "assistant" ? "assistant" : "user",
    content: String(m?.content || "").slice(0, 2000)
  })).filter(m => m.content) : [];
  try {
    const upstream = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.AI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        messages: [
          { role: "system", content: "You are 228 AI, a knowledgeable Persian-language gaming assistant. Answer questions about video games, gameplay, genres, platforms, game history, developers, accessibility, and troubleshooting. Be clear and useful. Do not invent facts, current news, prices, release dates, or patch notes; state uncertainty and say when live verification is needed. Keep answers suitable for a teen audience and avoid graphic descriptions. Reply in Persian unless the user asks for another language." },
          ...history,
          { role: "user", content: message }
        ],
        temperature: 0.4
      })
    });
    if (!upstream.ok) throw new Error(`AI provider responded ${upstream.status}`);
    const data = await upstream.json();
    res.json({ answer: data.choices?.[0]?.message?.content || "پاسخی دریافت نشد.", mode: "connected-ai" });
  } catch (error) {
    res.json({ answer: localGameAnswer(message) + "\n\n(سرویس هوش مصنوعی آنلاین موقتاً پاسخ نداد؛ این پاسخ از دانش محلی سایت است.)", mode: "local-fallback" });
  }
});

app.listen(PORT, () => console.log(`228GAME running at http://localhost:${PORT}`));
